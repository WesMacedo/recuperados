<?php

    const MERCADO_PAGO_CONFIG = [
         // https://www.mercadopago.com.br/developers/pt/docs/credentials
        "access_token"     => "YOUR_ACCESS_TOKEN",
        "notification_url" => "https://example.com/payment/notification.php"
    ];

    const DATABASE_CONFIG = [
        "drive"  => "mysql",
        "host"   => "localhost",
        "user"   => "root",
        "pass"   => "",
        "dbname" => "your_site"
    ];
